from framwork import *
import snake
import stage_eternal_night

class TestGame(GameFramework):
    def __init__(self,width=800,height=600):
        super().__init__("TestGame",width,height)
    def update(self):
        self.text_out("This is Test Game",(250,400),36,(255,0,0))
        return super().update()
    def on_key_down(self, key):
        if key==pygame.K_ESCAPE:
            self.end()
        return super().on_key_down(key)

if __name__=="__main__":
    game=TestGame()
    game_manger=GameManager()
    game_manger.register_game(game)
    game_manger.register_game(snake.Snake())
    game_manger.register_game(stage_eternal_night.TouhouStage())
    game_manger.run()
    game_manger.loop()